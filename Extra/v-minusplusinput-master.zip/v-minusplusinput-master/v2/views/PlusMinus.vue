<template>
  <div>
    <plusminsfield></plusminsfield>
  </div>
</template>

<script>
import PlusMinusField from '../components/PlusMinusField.vue'

export default {
  name: 'plusminusview',
  components: {
    'plusminsfield': PlusMinusField
  },
  data () {
    return {}
  },
  methods: {}
}
</script>
