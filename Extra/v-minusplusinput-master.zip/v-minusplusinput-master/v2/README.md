# VueJs V2 style component of PlusMinusField

if you have generated your app with CLI 3 and have a components folder, Here is the component

## Calling in vues

Please rerefer to `v2/views/PlusMinus.vue`